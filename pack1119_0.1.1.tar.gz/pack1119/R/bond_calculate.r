###########        债券价格     ##########
bond_offer=function(t,m,P,c=NULL,r){
  #t:到期年限
  #m:每年付息m次
  #P:票面价值
  #c:票息率
  #r:年收益率
  c=ifelse(is.null(c),0,c)
  k=1:(m*t)
  V=sum(c*P/m*(1/(1+r/m))^k)+P*(1/(1+r/m))**(m*t)
  return(V)
}

##################################################
########### 非付息交易日的债券价格  #######
bond_full=function(Vend,c,former,today,m){
  #V_end:今日债券收盘价
  #c:票息率
  #former:上一付息日,'Y-M-D'字符串格式
  #today:当前日期,'Y-M-D'字符串格式
  #m:每年付息m次
  library(lubridate)
  begin=as.Date(former)
  end=as.Date(today)
  d=as.numeric(difftime(end,begin,units="days"))
  Vfull=Vend+100*c/m*d/(365/m)
  return(list(Vfull=Vfull))
}


###################################################
######      计算债券的到期收益率      #########
yield=function(t,m,P,c=NULL,V){
  #t:剩余年限
  #m:每年付息m次
  #P:票面价值
  #c:票息率
  #V:债券目前价格

  c=ifelse(is.null(c),0,c)
  r0=seq(0,1,0.0001)
  V0=r0
  for (i in 1:length(r0)) {
    V0[i]=bond_offer(t,m,P,c,r0[i])
  }
  error=abs(V-V0)
  ind=which.min(error)
  ind=ind-1
  return(list(r=r0[ind]))
}



###################################################
###### 计算债券的修正久期/凸度/麦考利久期 #########

dura=function(c,m,t,r,P=NULL){
  #t:到期年限
  #m:每年付息m次
  #P:票面价值
  #c:票息率
  #r:年收益率
  P=ifelse(is.null(P),1,P)
  i=1:(m*t)
  V=bond_offer(t,m,P,c,r)
  ct=rep(P*c/m,m*t-1)
  ct=c(ct,P+P*c/m)
  D=sum(i/m*ct*(1/(1+r/m))^i)/V  #麦考利久期
  Dm=D/(1+r/m) #修正久期
  C=sum(i*(i+1)*ct*(1/(1+r/m))^(i+2))/m/m/V #凸度
  return(list(Dm=Dm,C=C,D=D))
}


###################################################
######        单个债券的风险免疫          #########
debt0=function(t,Pt,r,m){  #求负债现值
  return(Pt*(1/(1+r/m))^(t*m))
}

face_value=function(r,c,tb,mb,P0){
  #计算现金P0可购买多少面值的单个债券
  k=1:(mb*tb)
  fv=P0/(sum(c/mb*(1/(1+r/mb))^k)+(1/(1+r/mb))**(mb*tb))
  return(fv)
}

immu_single=function(t,m,P0=NULL,Pt=NULL,r,c,tb,mb){
  #t:负债期限
  #m:负债看成零息债券,该零息债券一年付息m次
  #P0:债务现值
  #Pt:债务终值,P0和Pt至少输入一个
  #r:当前收益率
  #c:债券的票息率
  #tb:债券期限
  #mb:债券一年付息mb次
  P0=ifelse(is.null(P0),debt0(t,Pt,r,m),P0)
  D0=dura(c=0,m,t,r,P=P0)$Dm
  C0=dura(c=0,m,t,r,P=P0)$C
  Pb=face_value(r,c,tb,mb,P0)
  priceb=P0/Pb
  Db=dura(c,m=mb,t=tb,r,P=Pb)$Dm
  Cb=dura(c,m=mb,t=tb,r,P=Pb)$C

  #利率变化范围
  r_range=seq(r-0.03,r+0.03,by=0.01)
  #每次付息额
  interest_per=rep(Pb*c/mb,length(r_range))
  #息票总值
  interest_total=rep(Pb*c*tb,length(r_range))
  #利息复利总值
  worth1=rep(0,length(r_range))
  for(i in 1:length(r_range)){
    worth1[i]=sum(Pb*c/mb*(1+r_range[i]/mb)^(0:(mb*tb-1)))
  }
  #债券面值
  faceb=rep(Pb,length(r_range))
  #债券的累积价值的终值
  cumulated=worth1+faceb
  re_single=cbind(r_range,interest_per,interest_total,worth1,faceb,cumulated)
  colnames(re_single)=c("收益率","每次付息额","息票总值","利息复利总值","债券面值","债券的累积价值的终值")
  re_DC=cbind(D0,C0,Db,Cb,priceb)
  colnames(re_DC)=c("负债久期","负债凸度","债券久期","债券凸度","债券价格")
  return(list(re_single=as.data.frame(re_single),re_DC=as.data.frame(re_DC)))
}




